#!/bin/bash

# file: lock.c
# Put this file under the path $PATH
# For example, ~/bin/

i3lock -c 000000 -d
xset dpms force off
